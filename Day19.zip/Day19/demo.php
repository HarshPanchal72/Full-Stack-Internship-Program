<html>
    <body>
        <?php 
        echo "Hii I am Harsh Panchal"
        ?>
        
        </body>
        </html>
    