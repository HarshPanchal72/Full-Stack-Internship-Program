
<html>
<body>

<?php
$x = 50;  
$y = "100";

echo var_dump($x == $y)."<br>"; 
echo var_dump($x >= $y)."<br>";
var_dump($x != $y);

?>  

</body>
</html>