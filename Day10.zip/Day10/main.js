function calcnumbers(result){
    Form.displayresult.value=Form.displayresult,value+result;
}